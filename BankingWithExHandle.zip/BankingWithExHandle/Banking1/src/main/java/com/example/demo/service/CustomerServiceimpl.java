package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.customerDto.CustomerDto;
import com.example.demo.dao.CustomerDao;
import com.example.demo.model.Customer;


@Service
public class CustomerServiceimpl {
	private static final Logger logger = LoggerFactory.getLogger(CustomerServiceimpl.class);
	ModelMapper modelMapper = new ModelMapper();
	List<CustomerDto> list=new ArrayList();
	
	private int accNO=200000;
	private int pass=123456;
	
	@Autowired
	private CustomerDao customerDao;

	public String addCustomerDetails(Customer cust) {
		if (cust.getCust_age() >= 21) {
			cust.setCust_acc("SBI"+(accNO++));
			cust.setCust_passwd((pass++)+"pass");
			customerDao.save(cust);
			return "Successfully Saved";
		} else {
			return "Not eligible to have account";
		}
	}
	
	public Iterable<Customer> getAll() {
		return customerDao.findAll();
	}

	public Optional<Customer> getCustomerById(Integer cust_Id) {
		return customerDao.findById(cust_Id);
	}

	public void deleteById(Integer cust_id1) {
		customerDao.deleteById(cust_id1);
	}

	public void updateById(Integer cust_id2,Customer cust3) {
		Customer details=customerDao.findById(cust_id2).orElse(cust3);
		details.setCust_email(cust3.getCust_email());
		details.setCust_job(cust3.getCust_job());
		details.setCust_phoneNo(cust3.getCust_phoneNo());
		customerDao.save(details);
	}
	
	public List<CustomerDto> getDto(){
	customerDao.findAll().forEach(customer->convertToDTo(customer));	
	return list;
	}
	private void convertToDTo(Customer customer){
		list.add(modelMapper.map(customer,CustomerDto.class));
	}
	
}
