package com.example.demo.customerDto;

public class CustomerDto {
private String cust_name;
private String cust_email;
private int cust_age;
private long cust_phoneNO;
public String getCust_name() {
	return cust_name;
}
public void setCust_name(String cust_name) {
	this.cust_name = cust_name;
}
public String getCust_email() {
	return cust_email;
}
public void setCust_email(String cust_email) {
	this.cust_email = cust_email;
}
public int getCust_age() {
	return cust_age;
}
public void setCust_age(int cust_age) {
	this.cust_age = cust_age;
}
public long getCust_phoneNO() {
	return cust_phoneNO;
}
public void setCust_phoneNO(long cust_phoneNO) {
	this.cust_phoneNO = cust_phoneNO;
}

}
