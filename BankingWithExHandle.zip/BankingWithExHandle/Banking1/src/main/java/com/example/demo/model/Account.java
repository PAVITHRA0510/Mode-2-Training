package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Account {
	@Id
	@Column(name = "cust_acc")
	private String cust_acc;
	@Column(name = "balance")
	private float balance;
	public String getCust_acc() {
		return cust_acc;
	}
	public void setCust_acc(String cust_acc) {
		this.cust_acc = cust_acc;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	
	
	
	
}
