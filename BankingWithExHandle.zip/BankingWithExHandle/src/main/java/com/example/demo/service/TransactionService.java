package com.example.demo.service;


import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.customerDto.TransactionDto;
import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.handler.AccountNotFoundException;
import com.example.demo.handler.BalanceInsufficientException;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;




@Service
public class TransactionService {
	
	float fromBalance,toBalance;
	ModelMapper mapp=new ModelMapper();
	List list=new ArrayList();
	
	@Autowired
	private AccountDao accountDao;
 
	@Autowired
	private TransactionDao transactionDao;
	
	public String addTransaction(Transaction trans) {
		transactionDao.save(trans);
		return "Transaction details saved....";
		}
		
		public Iterable<Transaction> getAll() {
			return transactionDao.findAll();
		}
	
		/*public String checkBalance(String acc_no,Transaction trans){
			Account accNo=accountDao.findById(acc_no).orElse(null);
			if(accNo==null){
				return "Account not found";
			}
			trans.setCust_accfrom(accNo.getCust_acc());
			trans.setCust_accto(trans.getCust_accto());
			trans.setCust_amount(trans.getCust_amount());
			trans.setDescription(trans.getDescription());
			trans.setTranscation_type(trans.getTranscation_type());
			transactionDao.save(trans);
			if(accNo.getBalance()>trans.getCust_amount()){
			return "you can make transaction";
			}
			return "you can't make transaction";
		}*/
		
		/*public String transaction(Transaction trans1,Account acc1){
			transactionDao.save(trans1);
			Transaction translist=transactionDao.findById(trans1.getCust_accfrom()).orElse(trans1);
			Account acclist1=accountDao.findById(trans1.getCust_accfrom()).orElse(acc1);
			Account acclist2=accountDao.findById(trans1.getCust_accto()).orElse(acc1);
			
			if(translist.getCust_amount()<acclist1.getBalance()){
				fromBalance=acclist1.getBalance();
				toBalance=acclist2.getBalance();
				fromBalance=fromBalance-translist.getCust_amount();
				toBalance=toBalance+translist.getCust_amount();
				acclist1.setBalance(fromBalance);
				acclist2.setBalance(toBalance);
				accountDao.save(acclist1);
				accountDao.save(acclist2);
				trans1.setCust_accfrom(translist.getCust_accto());
				trans1.setCust_amount(translist.getCust_amount());
				trans1.setDescription("Recieved from"+translist.getCust_accfrom());
				trans1.setTranscation_type("credited");
				transactionDao.save(trans1);
				return "Transaction Over";
			}
			return "Transaction Over";
		}*/
		
		public String transaction1(Transaction trans1,Account acc1,String to_cust){
			transactionDao.save(trans1);
			Transaction translist=transactionDao.findById(trans1.getCust_acc()).orElse(trans1);
			Account acclist1=accountDao.findById(trans1.getCust_acc()).orElse(acc1);
			Account acclist2=accountDao.findById(to_cust).orElse(acc1);
			if(translist.getCust_amount()<acclist1.getBalance()){
				System.out.println("You have sufficient balance to make transaction!!");
				fromBalance=acclist1.getBalance();
				toBalance=acclist2.getBalance();
				fromBalance=fromBalance-translist.getCust_amount();
				toBalance=toBalance+translist.getCust_amount();
				acclist1.setBalance(fromBalance);
				acclist2.setBalance(toBalance);
				accountDao.save(acclist1);
				accountDao.save(acclist2);
				trans1.setCust_acc(to_cust);
				trans1.setCust_amount(translist.getCust_amount());
				trans1.setDescription("Recieved from"+translist.getCust_acc());
				trans1.setTranscation_type("credited");
				transactionDao.save(trans1);
				return "Transaction Over";
			}
			else{
				throw new BalanceInsufficientException("balance"+acclist1.getBalance()+"is low");
			}
			
			//return "your balance is less, you can't make transaction";
		}
		public String transaction2(TransactionDto transdto){
			Account acc3=new  Account();
			list.add(mapp.map(acc3,TransactionDto.class));
			//transactionDao.save(trans1);
			//Transaction translist=transactionDao.findById(trans1.getCust_acc()).orElse(trans1);
			Account acclist1=accountDao.findById(transdto.getFromcust_accno()).orElse(null);
			Account acclist2=accountDao.findById(transdto.getTocust_accno()).orElse(null);
			Transaction trans=new Transaction();
			trans.setCust_acc(transdto.getFromcust_accno());
			trans.setCust_amount(transdto.getCust_amount());
			trans.setDescription("send to"+transdto.getTocust_accno());
			trans.setTranscation_type("debit");
			transactionDao.save(trans);
			
			if(transdto.getCust_amount()<acclist1.getBalance()){
				System.out.println("You have sufficient balance to make transaction!!");
				fromBalance=acclist1.getBalance();
				toBalance=acclist2.getBalance();
				fromBalance=fromBalance-transdto.getCust_amount();
				toBalance=toBalance+transdto.getCust_amount();
				acclist1.setBalance(fromBalance);
				acclist2.setBalance(toBalance);
				accountDao.save(acclist1);
				accountDao.save(acclist2);
			trans.setCust_acc(transdto.getTocust_accno());
				trans.setCust_amount(transdto.getCust_amount());
				trans.setDescription("received from"+transdto.getFromcust_accno());
				trans.setTranscation_type("credit");
				transactionDao.save(trans);
				return "Transaction Over";
			}
			
			return "your balance is less, you can't make transaction";
		}

		public TransactionDto getTransactionDetails(String cust_acc) {
			Transaction accnum = transactionDao.findById(cust_acc).orElse(null);
			if(accnum==null){
				throw new AccountNotFoundException("accountnumber" +cust_acc+ "not found in database");
			}
			TransactionDto transdto=mapp.map(accnum,TransactionDto.class);
			return transdto;
		}

		public List<Transaction> getAllCustomersByPage(Integer pageNo, Integer pageSize) {

		    {

		        Pageable paging = PageRequest.of(pageNo, pageSize);

		 

		        Page<Transaction> pagedResult = transactionDao.findAll(paging);

		         

		        if(pagedResult.hasContent()) {

		            return pagedResult.getContent();

		        } else {

		            return new ArrayList<Transaction>();

		        }
		}

		
			

				
		}}

