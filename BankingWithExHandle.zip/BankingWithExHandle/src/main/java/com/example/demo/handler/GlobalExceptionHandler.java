package com.example.demo.handler;

/*import java.time.LocalDate;

import org.modelmapper.spi.ErrorMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


public class GlobalExceptionHandler  extends ResponseEntityExceptionHandler{

	@ExceptionHandler(value = BalanceInsufficientException.class)
	public ResponseEntity<ErrorMessage> handleException( BalanceInsufficientException exception, WebRequest request) {
		ErrorMessage errorMessage = 
				new ErrorMessage(exception.getMessage(),LocalDate.now(),request.getDescription(false);
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);
	}

}



package com.demo.studentdb.exception;
*/
import java.time.LocalDate;

import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(AccountNotFoundException exception, WebRequest request) {
		ErrorMessage errorMessage = 
				new ErrorMessage(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(BalanceInsufficientException.class)
	public ResponseEntity<ErrorMessage> handleException1( BalanceInsufficientException exception, WebRequest request) {
		ErrorMessage errorMessage = 
				new ErrorMessage(exception.getMessage(), LocalDate.now(), request.getDescription(false));
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);
	}
}

