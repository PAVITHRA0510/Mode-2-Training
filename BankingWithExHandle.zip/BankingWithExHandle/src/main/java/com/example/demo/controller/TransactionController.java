package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.customerDto.TransactionDto;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {


	@Autowired
	TransactionService transactionService;
	
	@RequestMapping(value="/transaction/add")
	public String addTransaction(@RequestBody Transaction trans) {
		return transactionService.addTransaction(trans);
	}
	
	@RequestMapping(value="/transaction/get", method=RequestMethod.GET )
	public Iterable<Transaction> getAll( ){
		return	transactionService.getAll();
		}
	/*@RequestMapping(value="/transaction/check/{cust_acc}")
	public String checkBalance(@PathVariable(value = "cust_acc") String acc,@RequestBody Transaction trans){
		return transactionService.checkBalance(acc, trans);
	}
	*/
	/*@RequestMapping(value="/transaction/trans")
	public String transaction(@RequestBody Transaction trans,Account acc){
		return transactionService.transaction(trans, acc);
	}
*/
	@RequestMapping(value="/transaction/trans/{cust_acc}")
	public String transaction1(@PathVariable(value = "cust_acc") String to_cust,@RequestBody Transaction trans,Account acc){
		return transactionService.transaction1(trans, acc,to_cust);
	}
	@RequestMapping(value="/transaction/transdto")
	public String transaction2(TransactionDto transdto){
		return transactionService.transaction2(transdto);
	}
	@PostMapping("/transaction/get")
	public TransactionDto getTransactionDetails(@RequestBody String cust_acc)
	{
		return transactionService.getTransactionDetails(cust_acc); 
	}
	
	@GetMapping(value="/transaction/sp")
    public ResponseEntity<List<Transaction>> getAllCustomersByPage(@RequestParam Integer pageNo, 
    		@RequestParam Integer pageSize) {
        System.out.println("getAllCustomersByPage----->" );
        List<Transaction> list = transactionService.getAllCustomersByPage(pageNo, pageSize);
        return new ResponseEntity<List<Transaction>>(list, new HttpHeaders(), HttpStatus.OK); 

    }

}
