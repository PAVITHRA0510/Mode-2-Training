package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="theater")
public class Theater {
	@Id
	 private Integer theaterId;
	private String theaterName;
	private String theaterPlace;
	public Integer getTheaterId() {
		return theaterId;
	}
	public void setTheaterId(Integer theaterId) {
		this.theaterId = theaterId;
	}
	public String getTheaterName() {
		return theaterName;
	}
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	public String getTheaterPlace() {
		return theaterPlace;
	}
	public void setTheaterPlace(String theaterPlace) {
		this.theaterPlace = theaterPlace;
	}
	

}
