package com.example.demo.service;

 
import java.time.LocalTime;
import java.util.ArrayList;
 
import java.util.List;

 
import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.stereotype.Service;

 
import com.example.demo.dao.BookinDao;
 
import com.example.demo.dao.Showdao;
 
import com.example.demo.dao.TheaterDao;
 
import com.example.demo.model.Booking;
 
import com.example.demo.model.Show;
 
import com.example.demo.model.Theater;

 
@Service
 
public class BookService {
 
@Autowired 
 
BookinDao bookingdao;
 
@Autowired
 
TheaterDao theaterdao;
 
@Autowired 
 
Showdao showdao;
 
public Booking addBooking(String movieName,Integer theaterId,String showTime,int userId) {
 
Theater theater= theaterdao.findById(theaterId).orElse(null);
 
Show show=showdao.findById(theaterId).orElse(null);
 
Booking b=new Booking();


 
b.setUserId(userId);
 
b.setShowTime(showTime);
 
b.setMovieName(movieName);
 
b.setTheaterNmae(theater.getTheaterName());

 
b.setDate(show.getShowdate());

 
return bookingdao.save(b);


 
//return "Successfully entered the Booking details";
 

}



}
