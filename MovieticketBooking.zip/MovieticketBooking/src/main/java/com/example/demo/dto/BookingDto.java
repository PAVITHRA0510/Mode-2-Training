package com.example.demo.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class BookingDto {
 private String movieName;
 private String theaterNmae;
 private LocalTime showTime;
 private String place;
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getTheaterNmae() {
	return theaterNmae;
}
public void setTheaterNmae(String theaterNmae) {
	this.theaterNmae = theaterNmae;
}
public LocalTime getShowTime() {
	return showTime;
}
public void setShowTime(LocalTime showTime) {
	this.showTime = showTime;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}

}
 

