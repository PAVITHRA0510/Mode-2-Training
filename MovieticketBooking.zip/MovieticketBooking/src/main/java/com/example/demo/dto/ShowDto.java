package com.example.demo.dto;

public class ShowDto {
	private String showSearch;

	public String getShowSearch() {
		return showSearch;
	}

	public void setShowSearch(String showSearch) {
		this.showSearch = showSearch;
	}

}
