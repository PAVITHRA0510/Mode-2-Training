package com.example.demo.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Show;
import com.example.demo.model.Theater;
@Repository
public interface Showdao  extends CrudRepository<Show,Integer>{
	@Query(value="select * from showstables s where s.theater_id IN (select t.theater_id from  theater where t.theater_name=?1 or t.place=?1)",nativeQuery=true)
	 
	public List<Theater> find(LocalDate showdate);
	@Query(value="select * from showstable s where s.morn_show=?1 or s.noon_show=?1 or s.eve_show=?1",nativeQuery=true)
	 
	public List<Show> findByMovieName(@Param("movieName")String movieName);

	}



