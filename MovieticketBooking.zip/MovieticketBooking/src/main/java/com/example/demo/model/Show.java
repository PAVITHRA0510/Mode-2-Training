package com.example.demo.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="showstable")
public class Show {
	private LocalDate showdate;
	@Id
	private Integer theaterId;
	private String mornShow;
	private String noonShow;
	private String eveShow;
	public LocalDate getShowdate() {
		return showdate;
	}
	public void setShowdate(LocalDate showdate) {
		this.showdate = showdate;
	}
	public Integer getTheaterId() {
		return theaterId;
	}
	public void setTheaterId(Integer theaterId) {
		this.theaterId = theaterId;
	}
	public String getMornShow() {
		return mornShow;
	}
	public void setMornShow(String mornShow) {
		this.mornShow = mornShow;
	}
	public String getNoonShow() {
		return noonShow;
	}
	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}
	public String getEveShow() {
		return eveShow;
	}
	public void setEveShow(String eveShow) {
		this.eveShow = eveShow;
	}
}
	
	
	


