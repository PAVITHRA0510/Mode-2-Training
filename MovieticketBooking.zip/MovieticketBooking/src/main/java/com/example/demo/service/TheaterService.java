package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.TheaterDao;
import com.example.demo.model.Theater;
import com.example.demo.model.User;
@Service
public class TheaterService {

	@Autowired
 private TheaterDao theaterdao;

	public String addTheaterDetails(Theater theater) {
		theaterdao.save(theater);
		return "theater details saved successfully";
	}
	public List<Theater> find(String movieName) { 

		 
		List<Theater> p=theaterdao.find(movieName);
		 
		return p;

		}


}
