package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Theater;

@Repository
public interface TheaterDao extends CrudRepository<Theater,Integer> {
	@Query(value="select * from theater t where t.theater_id IN (select s.theater_id from showstable s where s.morn_show=?1 or s.noon_show=?1 or s.eve_show=?1 or s.showdate=?1)",nativeQuery=true)
	 
	public List<Theater> find(String movieName);

}
