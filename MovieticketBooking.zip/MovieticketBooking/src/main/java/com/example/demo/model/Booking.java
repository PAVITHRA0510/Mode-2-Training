package com.example.demo.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="booking")
public class Booking {
 private String movieName;
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private Integer bookingId;
 private String theaterNmae;
 private String showTime;
 private LocalDate date;
 private int userId;
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public Integer getBookingId() {
	return bookingId;
}
public void setBookingId(Integer bookingId) {
	this.bookingId = bookingId;
}
public String getTheaterNmae() {
	return theaterNmae;
}
public void setTheaterNmae(String theaterNmae) {
	this.theaterNmae = theaterNmae;
}
public String getShowTime() {
	return showTime;
}
public void setShowTime(String showTime) {
	this.showTime = showTime;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
 
}
