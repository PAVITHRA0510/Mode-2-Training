
package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Booking;
import com.example.demo.model.Movie;
import com.example.demo.service.BookService;
import com.example.demo.service.ShowService;

@RestController
public class BookingController {
	@Autowired
  private BookService bookservice;

@PostMapping(value="/movie/make/booking")
 
public Booking addShowDetails(@RequestParam String movieName,@RequestParam Integer theaterId,@RequestParam String showTime,@RequestParam int userId ){
 
return (Booking) bookservice.addBooking(movieName,theaterId,showTime,userId);

}
}
