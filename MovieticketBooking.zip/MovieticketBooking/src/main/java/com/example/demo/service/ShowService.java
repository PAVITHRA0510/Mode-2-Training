package com.example.demo.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.MovieDao;
import com.example.demo.dao.Showdao;
import com.example.demo.dao.TheaterDao;
import com.example.demo.dto.FinalDto;
import com.example.demo.dto.ShowDto;
import com.example.demo.handler.MovieNotFoundException;
import com.example.demo.model.Movie;
import com.example.demo.model.Show;
import com.example.demo.model.Theater;
@Service
public class ShowService {
@Autowired
TheaterDao theaterdao;

@Autowired 
private Showdao showdao;
public String addShowDetails(Show show) {
	showdao.save(show);
	return "show details saved successfully";
}
public String checkMovie(ShowDto showdto) throws IOException {
	   int flag = 0;
	   List<Show> list = (List<Show>) showdao.findAll();
	   for (Show show1 : list) {
	    if (showdto.getShowSearch().equalsIgnoreCase(show1.getMornShow())
	      || showdto.getShowSearch().equalsIgnoreCase(show1.getNoonShow())
	      || showdto.getShowSearch().equalsIgnoreCase(show1.getEveShow())) {
	     flag = 1;
	     return "movie exists....";
	    }
	   }
	   if (flag == 0) {
	    //throw new MovieNotFoundException("movie not exists...");
	    return "movie not exists...";
	   }
	   return null;
	  }
/*public void getShowDetails(Integer theater_id){
Show getShowDetails(Show show){
	forEach(Show show:showDetails){
		return show;
	}*/
public List<Theater> findDate(LocalDate showdate) { 

	 
	List<Theater> p=showdao.find(showdate);
	 
	return p;

	}
public List<FinalDto> showList(String movieName){
	List<Show> listShow=showdao.findByMovieName(movieName);
	Theater theater1=new Theater();
	
	List<FinalDto> list=new ArrayList();
	
	for(Show show:listShow){
		FinalDto finaldto=new  FinalDto();
		Integer theater_id=show.getTheaterId();
		theater1=theaterdao.findById(theater_id).orElse(null);
		finaldto.setTheaterPlace(theater1.getTheaterPlace());
		finaldto.setTheaterName(theater1.getTheaterName());
		finaldto.setMornShow(show.getMornShow());
		finaldto.setNoonShow(show.getNoonShow());
		finaldto.setEveShow(show.getEveShow());
		list.add(finaldto);
		
		
	}
	return list;
	
	
}
	
}
	 
