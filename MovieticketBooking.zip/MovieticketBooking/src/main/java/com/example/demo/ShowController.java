package com.example.demo;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.FinalDto;
import com.example.demo.dto.ShowDto;
import com.example.demo.model.Show;
import com.example.demo.model.Theater;
import com.example.demo.model.User;
import com.example.demo.service.ShowService;
import com.example.demo.service.UserService;
@RestController
public class ShowController {
	@Autowired
	ShowService showservice;

	@RequestMapping(value ="/movie/show/add")
	public String addShowDetails(@RequestBody Show show) {
		return showservice.addShowDetails(show);

	}
@PostMapping(value ="/movie/search/movie")
	public String checkMovie(@RequestBody ShowDto showdto)throws IOException {
		return showservice.checkMovie(showdto);

	}
@GetMapping(value="/movie/get/date/{showdate}") 

public List<Theater> getshow(@PathVariable LocalDate showdate) {
 
List<Theater> p=showservice.findDate(showdate);
 
return p;

}

@GetMapping(value="/movie/get/all")

public List<FinalDto> findMovieName(@RequestParam(value="movieName")String movieName){
 
System.out.println("entering..");
 
List<FinalDto> list=showservice.showList(movieName);
 
return list;


}

}

