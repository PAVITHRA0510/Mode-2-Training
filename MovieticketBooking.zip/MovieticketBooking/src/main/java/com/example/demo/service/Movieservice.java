package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.MovieDao;
import com.example.demo.model.Movie;


@Service
public class Movieservice {
	@Autowired 
	 private MovieDao moviedao;
	public String addMovieDetails(Movie movie) {
		moviedao.save(movie);
		return "movie details saved successfully";
	}
	
	}


