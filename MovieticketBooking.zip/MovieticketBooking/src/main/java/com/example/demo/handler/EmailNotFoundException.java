package com.example.demo.handler;

public class EmailNotFoundException  extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public EmailNotFoundException(String exception) {
		super(exception); 
	}
}
