package com.irctc.clientservicebooking.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.irctc.clientservicebooking.model.Passenger;
import com.irctc.clientservicebooking.services.PassengerService;

@RestController
public class PassengerController {
	@Autowired
	PassengerService passengerService;
	
	@PostMapping(value="/addpassenger/{numberOfSeats}/{userId}/{date}/{trainNumber}")
	public void addPassengers(@PathVariable int numberOfSeats, @PathVariable Integer userId, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @PathVariable Integer trainNumber, @RequestBody List<Passenger> passenger){
		passengerService.addPassengers(numberOfSeats,userId,date,trainNumber,passenger);
	}

	@DeleteMapping(value="/cancelTickets/{bookingId}")
		public String cancelTickets(@PathVariable int bookingId){
			return passengerService.cancelTickets(bookingId);
		}
	}
