package com.irctc.clientservicebooking.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Embeddable;


@Embeddable
public class CompositeUseridDate implements Serializable {
	Integer userId;
	LocalDate date;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public CompositeUseridDate(int userId, LocalDate date) {
		super();
		this.userId = userId;
		this.date = date;
	}
	public CompositeUseridDate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}