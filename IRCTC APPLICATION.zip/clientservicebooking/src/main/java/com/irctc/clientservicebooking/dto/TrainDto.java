package com.irctc.clientservicebooking.dto;

import java.time.LocalDate;

public class TrainDto {
	
	Integer trainNumber;
	LocalDate date;
	
	String trainName;
	String fromPlace;
	String toPlace;
	String totalTravelTime;
	int numberOfSeats;
	public Integer getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(Integer trainNumber) {
		this.trainNumber = trainNumber;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getTotalTravelTime() {
		return totalTravelTime;
	}
	public void setTotalTravelTime(String totalTravelTime) {
		this.totalTravelTime = totalTravelTime;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
	

}
