package com.irctc.clientservicebooking.services;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.irctc.clientservicebooking.dao.BookingDao;
import com.irctc.clientservicebooking.dao.PassengerDao;
import com.irctc.clientservicebooking.model.Booking;
import com.irctc.clientservicebooking.model.Passenger;

@Service
public class PassengerService {
	@Autowired
	BookingDao bookingDao;

	@Autowired
	PassengerDao passengerDao;

	public void addPassengers(int numberOfSeats, Integer userId, LocalDate date, Integer trainNumber,
			List<Passenger> passenger) {
		System.out.println("Hello");
		List<Booking> bookList = (List<Booking>) bookingDao.findAll();
		for (Booking b : bookList) {
			System.out.println("Hai");
			if (numberOfSeats == b.getNumberOfSeats() && userId.equals(b.getBookingDetails().getUserId())
					&& date.equals(b.getBookingDetails().getDate()) && trainNumber.equals(b.getTrainNumber())) {
				System.out.println("How");
				System.out.println(numberOfSeats);
				for (int i = 0; i < numberOfSeats; i++) {
					System.out.println(numberOfSeats);
					Passenger passengerObject = new Passenger();
					System.out.println("Bye");
					passengerObject.setPassengerName(passenger.get(i).getPassengerName());
					passengerObject.setPassengerAge(passenger.get(i).getPassengerAge());
					passengerObject.setUserId(userId);
					passengerObject.setTrainNumber(trainNumber);
					passengerDao.save(passengerObject);
				}
			}
		}
	}

	public String cancelTickets(int bookingId) {
		passengerDao.deleteById(bookingId);
		return "Cancelled tickets successfully";
	}
}
