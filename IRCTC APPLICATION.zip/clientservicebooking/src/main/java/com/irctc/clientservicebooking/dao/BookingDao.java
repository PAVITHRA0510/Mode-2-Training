package com.irctc.clientservicebooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.clientservicebooking.model.Booking;
import com.irctc.clientservicebooking.model.CompositeUseridDate;

@Repository
public interface BookingDao extends CrudRepository<Booking, CompositeUseridDate> {

}
