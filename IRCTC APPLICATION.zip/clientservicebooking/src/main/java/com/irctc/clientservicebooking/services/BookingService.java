package com.irctc.clientservicebooking.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.irctc.clientservicebooking.dao.BookingDao;
import com.irctc.clientservicebooking.dao.PassengerDao;
import com.irctc.clientservicebooking.dto.BookingHistoryDto;
import com.irctc.clientservicebooking.model.Booking;
import com.irctc.clientservicebooking.model.Passenger;

@Service
public class BookingService {
	@Autowired
	BookingDao bookingDao;
	
	@Autowired
	PassengerDao passengerDao;

	
	public Booking addBooking(Booking booking) {
		/*Booking book=new Booking();
		String uri = "/train/searchTrainnByTrainNumberAndDate/" +train.getTrainNumber()+"/"+train.getDate();
		TrainDto trainDetails=restTemplate.getForObject(uri, TrainDto.class);
		book.getBookingDetails().setDate(trainDetails.getDate());
		book.setTrainNumber(trainDetails.getTrainNumber());
		*/
		
		return bookingDao.save(booking);

	}

	/*public String addBookingQuery(Booking booking) {
		List<Registration> userList = (List<Registration>) registrationdao.findAll();
		List<Train> trainList = (List<Train>) traindao.findAll(); 
		for (Registration r : userList) {

			if (booking.getBookingDetails().getUserId().equals(r.getUserId())){

				for (Train t : trainList) {

					if (booking.getBookingDetails().getDate().equals(t.getComposite().getDate())
							&& booking.getTrainNumber().equals(t.getComposite().getTrainNumber())) {
						bookingDao.save(booking);
						return "booked Succesfully"; 
					}
				}
			}
		}
		return null;
	}*/
	
	

	public List<BookingHistoryDto> bookingHistory(Integer userId) {
		List<Passenger> passengerList = (List<Passenger>) passengerDao.findAll();
		List<Booking> bookingList = (List<Booking>) bookingDao.findAll();
		List<BookingHistoryDto> bookingHistoryList = new ArrayList<BookingHistoryDto>();
		for (Passenger p : passengerList) {
			if (userId.equals(p.getUserId())) {
				for (Booking b : bookingList) {
					if (userId.equals(b.getBookingDetails().getUserId())) {
						if (p.getTrainNumber().equals(b.getTrainNumber())) {
							BookingHistoryDto bookingHistory = new BookingHistoryDto();
							bookingHistory.setUserId(b.getBookingDetails().getUserId());
							bookingHistory.setTrainNumber(b.getTrainNumber());
							bookingHistory.setDate(b.getBookingDetails().getDate());
							bookingHistory.setNumberOfSeats(b.getNumberOfSeats());
							bookingHistory.setBookingId(p.getBookingId());
							bookingHistory.setPassengerName(p.getPassengerName());
							bookingHistory.setPassengerAge(p.getPassengerAge());
							bookingHistoryList.add(bookingHistory);
						}
					}
				}
			}
		}
		return bookingHistoryList;
	}	
}


