package com.irctc.clientservicebooking.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

@SuppressWarnings("serial")
@Entity
public class Booking implements Serializable {

	@Id
	private CompositeUseridDate bookingDetails;
	Integer trainNumber;
	int numberOfSeats;
	public CompositeUseridDate getBookingDetails() {
		return bookingDetails;
	}
	public void setBookingDetails(CompositeUseridDate bookingDetails) {
		this.bookingDetails = bookingDetails;
	}
	public Integer getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(Integer trainNumber) {
		this.trainNumber = trainNumber;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

}