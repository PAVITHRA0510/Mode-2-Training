package com.irctc.clientservicebooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.clientservicebooking.model.Passenger;

@Repository
public interface PassengerDao extends CrudRepository<Passenger, Integer> {

}
