package com.irctc.clientservicebooking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.irctc.clientservicebooking.dto.BookingHistoryDto;
import com.irctc.clientservicebooking.model.Booking;
import com.irctc.clientservicebooking.services.BookingService;

@RestController
public class BookingController {

	@Autowired
	BookingService bookingService;
	

	@PostMapping(value = "/book/booking")
	public Booking addBooking(@RequestBody Booking booking) {
		/*TrainSeatUpdateDto trainSeatUpdateDto=new TrainSeatUpdateDto();
		trainSeatUpdateDto.setNumberOfSeats(booking.getNumberOfSeats());
		System.out.println("Bye");
		System.out.println(booking.getTrainNumber());
		restTemplate.patchForObject("http://localhost:9092/train/update/" + booking.getTrainNumber(), trainSeatUpdateDto, String.class);*/
		return bookingService.addBooking(booking);
	}
	@GetMapping(value = "/book/bookingHistory/{userId}")
	public List<BookingHistoryDto> bookingHistory(@PathVariable Integer userId) {
		return bookingService.bookingHistory(userId);
	}
}
