package com.irctc.server.irctcserver.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class SuggestController {
	
	/*@Autowired
	   RestTemplate restTemplate;

	@Autowired
	TrainMicroService trainMicroService;
	
	@RequestMapping(value="/combine/{fromPlace}/{toPlace}/{date}",method=RequestMethod.GET)
	public TrainDto getCustomerDetails() {
		return trainMicroService.getCustomerDetails();
	}
*/	
	

}


