package com.irctc.server.irctcserver.service;

import org.springframework.stereotype.Service;


@Service
public class TrainMicroService {
	/* @Autowired
	   RestTemplate restTemplate;

	  @Autowired
	   RestTemplate restTemplate;
	   public String getProductList() {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange("http://localhost:9090/search/{fromPlace}/{toPlace}/{date}", HttpMethod.GET, entity, String.class).getBody();
	   }
	
	public TrainDto getCustomerDetails() {
		RestTemplate restTemplate = new RestTemplate();
		TrainDto list=restTemplate.getForObject("http://TRAINSERVICE/search/{fromPlace}/{toPlace}/{date}",TrainDto.class);
		return list;
	}
	public String getMovieDetails() {
		final String url = "http://localhost:9090/search/{trainNumber}";
		RestTemplate restTemplate = new RestTemplate();
		String list = restTemplate.getForObject(url, String.class);
		return list;
	}

*/}


