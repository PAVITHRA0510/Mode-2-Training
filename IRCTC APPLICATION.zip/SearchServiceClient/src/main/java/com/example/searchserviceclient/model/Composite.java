package com.example.searchserviceclient.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Embeddable;

@SuppressWarnings("serial")
@Embeddable
public class Composite implements Serializable {
	Integer trainNumber;
	LocalDate date;

	public Composite() {
		super();
	}

	public Integer getTrainNumber() {
		return trainNumber;
	}

	public void setTrainNumber(Integer trainNumber) {
		this.trainNumber = trainNumber;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Composite(Integer trainNumber, LocalDate date) {
		super();
		this.trainNumber = trainNumber;
		this.date = date;
	}
	

	}