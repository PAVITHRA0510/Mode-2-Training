package com.example.searchserviceclient.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@SuppressWarnings("serial")
@Entity
public class Train implements Serializable {
	@Id
	private Composite composite;
	
	String trainName;
	String fromPlace;
	String toPlace;
	String totalTravelTime;
	int numberOfSeats;
	public Composite getComposite() {
		return composite;
	}
	public void setComposite(Composite composite) {
		this.composite = composite;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getTotalTravelTime() {
		return totalTravelTime;
	}
	public void setTotalTravelTime(String totalTravelTime) {
		this.totalTravelTime = totalTravelTime;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}
}
