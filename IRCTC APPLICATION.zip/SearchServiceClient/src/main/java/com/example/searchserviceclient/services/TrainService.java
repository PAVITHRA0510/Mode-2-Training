package com.example.searchserviceclient.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.searchserviceclient.dao.TrainDao;
import com.example.searchserviceclient.model.Train;

@Service
public class TrainService {
	@Autowired
	private TrainDao trainDao;

	public String addTrainDetails(Train train) {
		trainDao.save(train);
		return "train details saved successfully";
	}

	public List<Train> searchTrainDetails(String fromPlace, String toPlace, LocalDate date) throws Exception {
				List<Train> train = trainDao.findByFromPlaceToPlaceDate(fromPlace, toPlace, date);
				if(train.isEmpty()){
					throw new Exception();
				}
				return train;
			}

	public List<Train> searchTrainDetailsByPnr(Integer trainNumber) throws Exception {
				List<Train> train = trainDao.findByTrainNumber(trainNumber);
				if(train.isEmpty()){
					throw new Exception();
				}
				return train;
	}

	/*public void updateNumberOfSeats(Integer trainNumber, TrainSeatUpdateDto numberOfSeats) {
		System.out.println("Hai");
		List<Train> trainList=(List<Train>) trainDao.findAll();
		for(Train t:trainList){
			if(trainNumber.equals(t.getComposite().getTrainNumber())){
				t.setNumberOfSeats(t.getNumberOfSeats()-numberOfSeats.getNumberOfSeats());
				trainDao.save(t);
			}
		}

		
	}
*/	}