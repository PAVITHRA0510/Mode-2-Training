package com.example.searchserviceclient.controllers;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.searchserviceclient.model.Train;
import com.example.searchserviceclient.services.TrainService;

@RestController
@CrossOrigin(origins="*")
public class TrainController {
	@Autowired
	TrainService trainservice;

	@PostMapping(value = "/train/addTrainDetails")
	public String addTrainDetails(@RequestBody Train train) {
		return trainservice.addTrainDetails(train);
	}

	@GetMapping(value = "/train/searchTrain/{fromPlace}/{toPlace}/{date}")
	public List<Train> searchTrainDetails(@PathVariable String fromPlace, @PathVariable String toPlace,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) throws Exception {
		return trainservice.searchTrainDetails(fromPlace, toPlace, date);
	}

	@GetMapping(value = "/train/searchTrainByTrainNumber/{trainNumber}")
	public List<Train> searchTrainDetailsByTrainNumber(@PathVariable int trainNumber) throws Exception {
		System.out.println("Hello");
		return trainservice.searchTrainDetailsByPnr(trainNumber);
	}

	/*@PatchMapping("/train/update/{trainNumber}")
	public String updateNumberOfSeats(@PathVariable Integer trainNumber, @RequestBody TrainSeatUpdateDto numberOfSeats)
	{
		trainservice.updateNumberOfSeats(trainNumber, numberOfSeats);
		return "Successfully updated";
	}
*/
}