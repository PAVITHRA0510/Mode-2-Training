/**
 * 
 */
/**
 * @author Training
 *
 */
package com.example.searchserviceclient.dto;