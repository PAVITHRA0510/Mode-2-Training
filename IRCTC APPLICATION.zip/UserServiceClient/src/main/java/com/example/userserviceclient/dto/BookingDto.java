package com.example.userserviceclient.dto;

import java.time.LocalDate;

public class BookingDto {
	
	CompositeUseridDate bookingDetails;
	Integer trainNumber;
	int numberOfSeats;
	public CompositeUseridDate getBookingDetails() {
		return bookingDetails;
	}
	public void setBookingDetails(CompositeUseridDate bookingDetails) {
		this.bookingDetails = bookingDetails;
	}
	public Integer getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(Integer trainNumber) {
		this.trainNumber = trainNumber;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

}
