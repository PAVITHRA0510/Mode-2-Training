
package com.example.userserviceclient.controller;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.userserviceclient.model.Registration;
import com.example.userserviceclient.service.LoginService;
import com.example.userserviceclient.service.RegisterService;

@RestController
@CrossOrigin(origins="*")
public class RegistrationController {
	@Autowired
	RegisterService registerService;

	@Autowired
	LoginService loginService;
	
	@RequestMapping(value = "/user/register")
	public String addregisterDetails(@RequestBody Registration registration) {
		return registerService.addUserDetails(registration);

	}

	@GetMapping(value = "/user/login/{userName}/{password}")
	public String checkLoginDetails(@PathVariable String userName, @PathVariable String password) throws IOException {
		return loginService.checkLogin(userName, password);

	}
}
