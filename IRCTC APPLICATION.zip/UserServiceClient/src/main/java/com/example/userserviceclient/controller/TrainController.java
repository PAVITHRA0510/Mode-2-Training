package com.example.userserviceclient.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.userserviceclient.dto.TrainDto;

@RestController
public class TrainController {
	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping(value = "/user/combine/{trainnumber}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<TrainDto> getTrainByTrainNumber(@PathVariable int trainnumber) {
		String uri = "http://SEARCHSERVICECLIENT/train/searchTrainByTrainNumber/" + trainnumber;
		return restTemplate.getForObject(uri, List.class);
	}
	
	@RequestMapping(value = "/user/combine/{fromPlace}/{toPlace}/{date}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<TrainDto> getTrainByFromPlaceToPlaceandDate(@PathVariable String fromPlace, @PathVariable String toPlace,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		String uri = "http://SEARCHSERVICECLIENT/train/searchTrain/" + fromPlace+"/"+toPlace+"/"+date;
		return restTemplate.getForObject(uri, List.class);
	}
}
