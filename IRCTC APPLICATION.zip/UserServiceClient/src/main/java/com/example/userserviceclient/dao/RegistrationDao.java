package com.example.userserviceclient.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.userserviceclient.model.Registration;

@Repository
public interface RegistrationDao extends CrudRepository<Registration, Integer> {

	@Query(value = "select * from registration r where r.user_id=?1", nativeQuery = true)
	List<Registration> findByUserByUserId(int userId);

	@Query(value="select * from registration r where r.user_name=?1 and r.password=?2", nativeQuery = true)
	List<Registration> findByUsernameAndPassword(String userName, String password);
}
