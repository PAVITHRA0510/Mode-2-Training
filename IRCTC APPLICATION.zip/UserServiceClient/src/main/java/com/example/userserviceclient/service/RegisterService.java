package com.example.userserviceclient.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.userserviceclient.dao.RegistrationDao;
import com.example.userserviceclient.model.Registration;


@Service
public class RegisterService {
	@Autowired
	private RegistrationDao registrationDao;

	public String addUserDetails(Registration registration) {
		// TODO Auto-generated method stub
		registrationDao.save(registration);
		return "user details saved successfully and your userID is "+registration.getUserId();
	}

	public List<Registration> checkUser(Integer userId) {
		// TODO Auto-generated method stub
		List<Registration> registration = registrationDao.findByUserByUserId(userId);
		return registration;
	}

}
