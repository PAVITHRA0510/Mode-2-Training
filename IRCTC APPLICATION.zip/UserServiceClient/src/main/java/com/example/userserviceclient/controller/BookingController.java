package com.example.userserviceclient.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.userserviceclient.dto.BookingDto;
import com.example.userserviceclient.dto.BookingHistoryDto;
import com.example.userserviceclient.dto.PassengerDto;

@RestController
public class BookingController {
	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping(value = "/user/book/booking", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public BookingDto bookingDetails(@RequestBody BookingDto booking) {
		String uri = "http://CLIENTSERVICEBOOKING/book/booking";
		return restTemplate.postForObject(uri,booking,BookingDto.class);
	}
	
	@RequestMapping(value = "/user/Passenger/{numberOfSeats}/{userId}/{date}/{trainNumber}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public void passengerDetails(@PathVariable int numberOfSeats, @PathVariable Integer userId, @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @PathVariable Integer trainNumber, @RequestBody List<PassengerDto> passenger) {
		String uri = "http://CLIENTSERVICEBOOKING/addpassenger/"+ numberOfSeats+"/"+userId+"/"+date+"/"+trainNumber;
		restTemplate.postForObject(uri,passenger,PassengerDto.class);
	}
	@DeleteMapping(value = "/user/cancelTicket/{bookingId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void cancelTicket(@PathVariable int bookingId) {
		String uri = "http://CLIENTSERVICEBOOKING/cancelTickets/"+ bookingId;
		restTemplate.delete(uri);
				//postForObject(uri,passenger,PassengerDto.class);
	}
	
	@RequestMapping(value = "/user/bookingHistory/{userId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<BookingHistoryDto> bookingHistory(@PathVariable Integer userId) {
		String uri = "http://CLIENTSERVICEBOOKING/book/bookingHistory/" + userId;
		return restTemplate.getForObject(uri, List.class);
	}
}
