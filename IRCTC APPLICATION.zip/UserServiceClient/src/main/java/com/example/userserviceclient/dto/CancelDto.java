package com.example.userserviceclient.dto;

public class CancelDto {

}
