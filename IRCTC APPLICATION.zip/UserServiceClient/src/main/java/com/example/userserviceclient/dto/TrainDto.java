package com.example.userserviceclient.dto;

public class TrainDto {
	int trainnumber;
	String trainname;
	int numberofseats;
    String totaltraveltime;
	public TrainDto(int trainnumber, String trainname, int numberofseats, String totaltraveltime) {
		super();
		this.trainnumber = trainnumber;
		this.trainname = trainname;
		this.numberofseats = numberofseats;
		this.totaltraveltime = totaltraveltime;
	}
	
	public TrainDto() {
		}

	public int getTrainnumber() {
		return trainnumber;
	}
	public void setTrainnumber(int trainnumber) {
		this.trainnumber = trainnumber;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public int getNumberofseats() {
		return numberofseats;
	}
	public void setNumberofseats(int numberofseats) {
		this.numberofseats = numberofseats;
	}
	public String getTotaltraveltime() {
		return totaltraveltime;
	}
	public void setTotaltraveltime(String totaltraveltime) {
		this.totaltraveltime = totaltraveltime;
	}
    

}
