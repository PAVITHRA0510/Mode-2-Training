package com.example.userserviceclient.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.userserviceclient.dao.RegistrationDao;
import com.example.userserviceclient.model.Registration;



@Service
public class LoginService {
	@Autowired
	RegistrationDao registrationdao;
	
	public String checkLogin(String userName, String password) throws IOException {
		List<Registration> loginList = registrationdao.findByUsernameAndPassword(userName, password);
		if(loginList.isEmpty()){
			throw new IOException();
		}
		return "Logged in successfully";
	}

}