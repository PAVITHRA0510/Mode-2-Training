package com.microservice.practice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.practice.model.Customer;
import com.microservice.practice.model.Movie;
import com.microservice.practice.service.MicroService;



@RestController
public class MainController {
@Autowired
MicroService microservice;

@GetMapping(value ="/list/finalcustomer")
public List<Customer> serviceControllerCustomerShow() {
	return microservice.getClient();

}
@GetMapping(value="/list/finalmovie")
public List<Movie> serviceControllerMovieShow() {
	return microservice.redirectToMovie();

}

}
