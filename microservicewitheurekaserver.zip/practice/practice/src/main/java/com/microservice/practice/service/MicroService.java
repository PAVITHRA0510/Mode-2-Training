package com.microservice.practice.service;

import java.util.List;

import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties.Web.Client;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.microservice.practice.model.Customer;
import com.microservice.practice.model.Movie;

@Service
public class MicroService {
RestTemplate rs=new RestTemplate();
 //to fetch customer details from Banking application by using eureka server-client concept(Miceoservices Concept)
public List<Customer>getClient()
{
List result=rs.getForObject("http://localhost:9914/customer/get",List.class);
 
return result ;

}
//to fetch movie details from MovieTicket booking application by using eureka server-client concept(Microservices concept)
public List<Movie> redirectToMovie(){
	List result1=rs.getForObject("http://localhost:8080/movie/get", List.class);
	return result1;
}


}
