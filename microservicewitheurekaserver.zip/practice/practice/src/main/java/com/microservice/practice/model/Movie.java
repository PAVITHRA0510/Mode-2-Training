package com.microservice.practice.model;

import java.time.LocalDate;

/*import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;*/


public class Movie {
	
	private String movieName;
	private String language;
	private LocalDate releasedate;
	
	
public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public LocalDate getReleasedate() {
		return releasedate;
	}
	public void setReleasedate(LocalDate releasedate) {
		this.releasedate = releasedate;
	}

}
