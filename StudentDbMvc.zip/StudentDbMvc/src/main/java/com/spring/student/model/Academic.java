package com.spring.student.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="academic")
public class Academic {
	
	
		@Id
		String usn;
		String course;
		int sem;
		public String getUsn() {
			return usn;
		}
		public void setUsn(String usn) {
			this.usn = usn;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public int getSem() {
			return sem;
		}
		public void setSem(int sem) {
			this.sem = sem;
		}
		
		
	}


