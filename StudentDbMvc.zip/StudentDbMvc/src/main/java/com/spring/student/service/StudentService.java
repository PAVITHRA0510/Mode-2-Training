package com.spring.student.service;

import java.util.List;

import javax.management.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.student.dao.StudentDao;
import com.spring.student.model.Student;

@Service

public class StudentService {
	Session session;
	@Autowired
	private StudentDao studentdao;
	
	@Transactional
	//To add student details into DataBase
	public void addPerson(Student cust) {
		studentdao.addPerson(cust);
	}
	//To fetch the student details from Database
	@Transactional public List<Student> listofstudents(){
		return this.studentdao.listofstudents();
	}
	//To add the pagination feature
	@Transactional
	public List<Student> getAll(int id,int total) {
		
		return studentdao.getAll(id,total);		
	}
	//To print the student details based upon the percentage
	 public List<Student>getByPercentage(){
		 return studentdao.getByPercentage();
	 }
}


