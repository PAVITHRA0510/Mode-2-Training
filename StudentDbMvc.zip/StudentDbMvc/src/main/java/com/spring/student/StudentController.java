package com.spring.student;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.student.model.Academic;
import com.spring.student.model.Student;
import com.spring.student.service.StudentService;

@Controller
public class StudentController {
	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
Academic academic;
Student student;
	@Autowired
	private StudentService studentservice;

	private Map<String,Student> stud = null;

	public StudentController() {
		stud = new HashMap<String, Student>();
	}

	@ModelAttribute("stud")
	public Student createUserModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new Student();
	}

	@RequestMapping(value = "/save/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		logger.info("Returning Studententry.jsp page");
		// model.addAttribute("user", new User());
		return "Studententry";
	}

	@RequestMapping(value = "/save/save.do", method = RequestMethod.POST)
	public String saveStudentAction(@ModelAttribute("stud") @Validated Student stud, BindingResult bindingResult,
			Model model) {

		if (bindingResult.hasErrors()) {
			logger.info("Returning Studententry.jsp page");
			return "Studententry";
		}
		logger.info("Returning regsuccess.jsp page");
		model.addAttribute("stud", stud);
		// customers.put(customer.getEmail(), customer);
		this.studentservice.addPerson(stud);
		return "regsuccess";
	}
	@RequestMapping(value = "/save/show", method = RequestMethod.GET)
	public String showStudent(Model model) {
		logger.info("Returning show.jsp page");
		model.addAttribute("stud", new Student());
		model.addAttribute("listofstudents",this.studentservice.listofstudents());
		return "show";
	}
	/*@RequestMapping(value = "/save/pagination", method = RequestMethod.GET)
	public String paginationStudent(Model model) {
		logger.info("Returning pagination.jsp page");
		model.addAttribute("stud", new Student());
		model.addAttribute("pagination",this.studentservice.getRecords(0, 2));
		return "pagination";
	}*/
	@RequestMapping(value = "/save/{pageid}", method = RequestMethod.GET)
	public ModelAndView getAllStudent(@PathVariable(value="pageid") int id) {
		int total = 2;
		if (id == 1) 
		{
		} 
		else {
			id = (id - 1) * total + 1;
		}
		ModelAndView model = new ModelAndView();
		logger.info("Studet getAll  place page");
		List<Student> list = studentservice.getAll(id,total);
		model.addObject("getAll", list);
		model.setViewName("pagination");
		return model;
	}
	@ResponseBody
	@RequestMapping(value = "/save/post/{pageid}", method = RequestMethod.GET)
	public List<Student> getAllStudentUsingPagination(@PathVariable(value="pageid") int id) {
		int total = 2;
		if (id == 1) {
		
		}
		
		
		else {
			id = (id - 1) * total + 1;
		}
		
		List<Student> list = studentservice.getAll(id,total);
		return list;
		
		//return list;
	}
	
	
	@RequestMapping(value = "/save/bypercentage")
	@ResponseBody
	public List<Student> showByPercentage(){
		return this.studentservice.getByPercentage();
	}
	
	/*public ModelAndView showByPercentage(Model model) {
		ModelAndView model1 = new ModelAndView();
		logger.info("Returning criteria.jsp page");
		 public List<Student> list = studentservice.getByPercentage();
		model1.addObject("getByPercentage", list);
		model1.setViewName("criteria");
		return model1;
	}*/
	@RequestMapping(value = "/save/inter", method = RequestMethod.GET)
	public String addStudentusingInternationalization(Model model) {
		logger.info("Returning inter.jsp page");
		// model.addAttribute("user", new User());
		return "inter";
	}
	
}
