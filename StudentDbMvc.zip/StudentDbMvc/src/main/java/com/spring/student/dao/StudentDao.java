package com.spring.student.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mysql.jdbc.Connection;
import com.spring.student.model.Student;

@Repository
public class StudentDao {
	private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);
	Session session;
	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	// To add student details into DataBase
	public void addPerson(Student student) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student);
		logger.info("Person saved successfully, Person Details=" + student);
	}

	// To fetch the student details from Database
	@SuppressWarnings("unchecked")
	public List<Student> listofstudents() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Student> plist = session.createQuery("from Student").list();
		for (Student l : plist) {
			logger.info("list elements are" + l);
		}

		return plist;

	}

	// To add the pagination feature
	public List<Student> getAll(int id, int total) {
		// Session session = this.sessionFactory.getCurrentSession();
		String hql1 = "from Student";
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(hql1);
		query.setFirstResult(id - 1);
		query.setMaxResults(total);
		List<Student> getAll = query.list();
		return getAll;
		// TODO Auto-generated method stub
	}

	// To print the student details based upon the percentage
	@Transactional
	public List<Student> getByPercentage() {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria c = session.createCriteria(Student.class);
		c.addOrder(Order.asc("percentage"));
		List<Student> list = c.list();
		return list;

	}
}