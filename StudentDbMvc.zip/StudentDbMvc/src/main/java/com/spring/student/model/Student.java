package com.spring.student.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Student")
public class Student {
	/*@Column(name = "USNNo")
		private String USNNo;*/
	@Id
	@Column(name = "USNNo")
	
	private String USNNo;
	
		@Column(name = "studName")
		private String studName;
		@Column(name = "studAge")
		private int studAge ;
		@Column(name = "studPhoneNo")
		private long studPhoneNo;
		@Column(name = "studEmail")
		private String studEmail;
		@Column(name = "studFather")
		private String studFather ;
		@Column(name = "studMother")
		private String studMother ;
		@Column(name = "percentage")
		private int percentage ;
		
		public String getUSNNo() {
			return USNNo;
		}
		public void setUSNNo(String uSNNo) {
			USNNo = uSNNo;
		}
		public int getPercentage() {
			return percentage;
		}
		public void setPercentage(int percentage) {
			this.percentage = percentage;
		}
		
		public String getStudName() {
			return studName;
		}
		public void setStudName(String studName) {
			this.studName = studName;
		}
		public int getStudAge() {
			return studAge;
		}
		public void setStudAge(int studAge) {
			this.studAge = studAge;
		}
		public long getStudPhoneNo() {
			return studPhoneNo;
		}
		public void setStudPhoneNo(long studPhoneNo) {
			this.studPhoneNo = studPhoneNo;
		}
		public String getStudEmail() {
			return studEmail;
		}
		public void setStudEmail(String studEmail) {
			this.studEmail = studEmail;
		}
		public String getStudFather() {
			return studFather;
		}
		public void setStudFather(String studFather) {
			this.studFather = studFather;
		}
		public String getStudMother() {
			return studMother;
		}
		public void setStudMother(String studMother) {
			this.studMother = studMother;
		}
		
		}

		
